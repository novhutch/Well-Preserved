# Evidence Map

Version 1.0 | 2026-10-22 | Draft

This page lists all seventeen scoring criteria, one row each, and says where a reader can find the evidence. "Reflective Analysis" means the matching section of my Reflective Analysis document.

| # | Criterion | Where to find the evidence |
|---|---|---|
| 1.1 | Archival principles in practice | [Mike Williams finding aid](../independent/03-arrangement-description/Mike-Williams-Finding-Aid_v1.0_2026-10-01.pdf), [Southall Brown finding aid](../independent/03-arrangement-description/Southall-Brown-Finding-Aid_v1.0_2026-10-01.pdf); Reflective Analysis, section [fill in] |
| 1.2 | Distinction from allied professions | Reflective Analysis, section [fill in] |
| 2.1 | Analysis of recordkeeping systems | [PastPerfect analysis](../independent/06-digital-records-access-systems/PastPerfect/README.md) |
| 2.2 | Born-digital and hybrid material | [Accession Record](../with-guidance/01-nature-of-records/Accession-Record_v1.0_2026-10-01.pdf), [Audiocassette Digitization Guide](../independent/05-preservation/Audacity/), [Preservation and Export Log](Preservation-and-Export-Log_v1.0_2026-10-22.md) |
| 3.1 | Appraisal and selection | [Planning Notes, Part A](Planning-Notes_v1.0_2026-10-22.md) |
| 3.2 | Arrangement and description | This [repo map](README.md), the version-naming rules on that page, and a README in every folder |
| 3.3 | Reference and access | "Start here" section of the [main README](../README.md) |
| 3.4 | Preservation and protection | [Preservation and Export Log](Preservation-and-Export-Log_v1.0_2026-10-22.md) |
| 3.5 | Outreach | [Main README](../README.md), [resume positioning statement](../resume/README.md) |
| 3.6 | Management of archival programs | [Planning Notes, Part B](Planning-Notes_v1.0_2026-10-22.md), [Build Log](../BUILD-LOG.md) |
| 4.1 | Records in social context | Reflective Analysis, section [fill in] |
| 4.2 | Representation and silence | Reflective Analysis, section [fill in] |
| 5.1 | Application of the professional ethical framework | [Ethics and Permissions, Part 1](Ethics-and-Permissions_v1.0_2026-10-22.md) |
| 5.2 | Legal and permissions practice | [Ethics and Permissions, Part 2](Ethics-and-Permissions_v1.0_2026-10-22.md) |
| 6.1 | Platform and information architecture | [Preservation and Export Log, "Why GitHub"](Preservation-and-Export-Log_v1.0_2026-10-22.md), link checks in the [Build Log](../BUILD-LOG.md) |
| 6.2 | Accessibility conformance | [Accessibility Remediation Log](Accessibility-Remediation-Log_v1.0_2026-10-22.md) |
| 6.3 | Preservation and sustainability | [Preservation and Export Log](Preservation-and-Export-Log_v1.0_2026-10-22.md) |
