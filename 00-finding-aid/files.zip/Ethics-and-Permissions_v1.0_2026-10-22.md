# Ethics and Permissions

Version 1.0 | 2026-10-22 | Draft

Items in [brackets] are mine to fill in or confirm. Before finishing, open the current SAA Core Values Statement and Code of Ethics (archivists.org) and use its exact section names. SAA's Council reviewed proposed revisions in August 2025, so check which version is current.

## Part 1: Ethical decisions in this portfolio

| Decision | What was at stake | SAA Code or Core Values it connects to | What I did and why |
|---|---|---|---|
| Honoring the donor's 25-year restriction on the military project files (Accession Record) [confirm details] | Wide access versus the donor's agreed limit | [Section name] | [Your reasoning] |
| Naming living people in the Southall Brown finding aid [confirm which details] | Privacy of living people versus useful description | [Section name] | [Your reasoning] |
| Handling the original tapes in the Digitization Guide | Keeping the original safe while making it usable | [Section name] | Work from copies; do not rewind after recording; keep master and access files separate |
| Sharing City of Savannah Archives work in a personal portfolio | The institution's rights versus my need to show my work | [Section name] | Asked for permission (see Part 2) |
| Children's lesson plans using the W. W. Law collection | Educational use versus rights in the images and letters | [Section name] | [Your reasoning] |

**One decision where two obligations pulled against each other**

[Pick the clearest one, probably the donor restriction. In 4 to 6 sentences: name the two obligations, say which you chose, and why.]

## Part 2: Permissions and clearances

**How clearances are documented.** I hold written permission for the items below. The messages are kept in my private records and are not posted here, because they contain personal contact details and internal correspondence. This page records who gave permission, when, and for what, so the clearance can be checked. The written messages are available to my instructor on request. [Decide whether to offer them to a hiring committee on request, too.]

| Item | Who holds the rights | Permission given by (job title is fine) | Date | What was approved | Written record |
|---|---|---|---|---|---|
| Mike Williams finding aid | Savannah Municipal Archives | [ ] | [ ] | [ ] | Held privately |
| Southall Brown finding aid | Savannah Municipal Archives | [ ] | [ ] | [ ] | Held privately |
| Audiocassette Digitization Guide and screenshots | Savannah Municipal Archives | [ ] | [ ] | [ ] | Held privately |
| Three lesson plans | [ ] | [ ] | [ ] | [ ] | Held privately [confirm] |
| Display photographs (4 images) | [ ] | [ ] | [ ] | [ ] | Held privately [confirm] |
| StoryRoots and PastPerfect links | Savannah Municipal Archives | [ ] | [ ] | [ ] | Held privately |
| Coursework artifacts (Accession Record, Deed of Gift, Records Management Policy, Strategic Plan, Patron Relations) | Me (fictional institutions) | Not needed [confirm no outside images or templates] | | | |
| Resume and certificates | Me | Not needed | | | |

**If permission is ever withdrawn:** the item comes out of the portfolio and the Build Log says so.
