# Planning Notes: Selection and Project Management

Version 1.0 | 2026-10-22 | Draft

Items in [brackets] are mine to fill in or confirm before this goes live.

## Part A: How I chose what goes in this portfolio

**My selection rules**

1. Each of the nine competency components gets one main artifact. Where I have both coursework and hands-on work for a component, both are shown and labeled. [Confirm]
2. Every artifact has to be viewable inside the portfolio itself. (Build Log, 2026-10-01: the Museum Presentation was too large to upload, so I replaced it with the Strategic Plan.)
3. Real work for the Savannah Municipal Archives is preferred over practice work when I have both. [Confirm]
4. I include only material I have permission to share. See [Ethics and Permissions](Ethics-and-Permissions_v1.0_2026-10-22.md).

**What I left out, and why**

- Museum Presentation: too large for GitHub. Replaced by the Strategic Plan.
- Hands-on physical preservation work from my preservation course (the greeting-card condition survey and the four-flap enclosure). [Your reason: for example, not tied to one of the nine components, or not cleared for sharing.]
- [Anything else you chose not to include.]

**What my selection makes invisible**

[Write 2 to 4 sentences in your own words. Starting points: the portfolio shows description and digitization much more than physical preservation; it shows no live reference work with patrons; the born-digital example is a transfer record, not a worked case; the voices of the people in the collections come through only in finding-aid notes.]

## Part B: How I managed building this portfolio

**Timeline (from the Build Log)**

| Date | What happened |
|---|---|
| 2026-10-01 | Version naming applied to all files. Museum Presentation replaced because of the file-size limit. |
| 2026-10-12 | Fingerprint (checksum) list created. First round of PastPerfect link checks. |
| 2026-10-14 | Lesson plans added to Outreach and Advocacy. |
| 2026-10-22 | Rubric self-score completed. Gaps found. This plan written. |
| [date] | [Fingerprint list rebuilt, export test done, accessibility fixes, and so on] |

**Effort: planned versus actual**

| Task | Hours I planned | Hours it took | Notes |
|---|---|---|---|
| Build the repository and folders | [ ] | [ ] | |
| Version naming and finding aid | [ ] | [ ] | |
| Fingerprint list and link checks | [ ] | [ ] | |
| Accessibility fixes | [ ] | [ ] | |
| Export test and backup | [ ] | [ ] | |

**Risks I identified and what I did**

| Risk | What happened or could happen | My response |
|---|---|---|
| File too large for GitHub | Happened 2026-10-01 | Replaced the file; rule 2 above |
| PastPerfect items are outside my control | Links could break or items could be removed | Link checks on a schedule; contact the Archives if one fails |
| Fingerprint list falls out of date when files are renamed | Happened: the list still named old file names on 2026-10-22 | Rebuilt on [date]; rebuild any time files change |
| Losing GitHub or my account | Portfolio would disappear | Second copy kept at [where]; last updated [date] |
| Permission withdrawn for an item | Item has to come down | Remove it, note it in the Build Log |

**How this connects to running an archives program**

[2 to 3 sentences in your own words: for example, a small archives with one or two staff would use the same habits, which are estimating time, writing down risks, checking on a schedule, and keeping a log of decisions.]
