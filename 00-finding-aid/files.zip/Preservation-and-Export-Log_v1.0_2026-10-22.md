# Preservation and Export Log

Version 1.0 | 2026-10-22 | Draft

Items in [brackets] are mine to fill in. Nothing in the results sections should be filled in until the step has actually been done.

## 1. Why GitHub

- The repository lives in my own GitHub account, not in my school account, so it does not depend on school logins that will end. [Confirm]
- GitHub keeps a History of every change, so earlier versions can be seen.
- The pages are plain text (Markdown), which can be read in any text program if GitHub ever goes away.
- [Add anything else about your choice, and what you considered instead.]

## 2. File formats

| Type | Files | Plan |
|---|---|---|
| PDF | Finding aids, Accession Record, Deed of Gift, Records Management Policy, Strategic Plan, resume, certificates | Keep as is |
| Word and PowerPoint | Three lesson plans, Digitization Guide, Patron Relations presentation | Keep the original and add a PDF copy beside it, with the same name and version |
| Pictures | Display photos, screenshots | Keep as is |
| Plain text | READMEs, this log, Build Log, fingerprint list | Keep as is |
| Unknown | The file named "Omeka" in folder 06 | [Open it, then say what it is and whether it needs a proper file name] |

## 3. Copies

| Where | What is there | Last updated |
|---|---|---|
| GitHub | Everything | [ ] |
| My computer | Full copy | [ ] |
| [External drive or cloud storage] | Full copy | [ ] |

## 4. Export test

I tested whether the whole portfolio can be taken out of GitHub and still work.

| Step | Done? | Result |
|---|---|---|
| Download the whole repository as a ZIP file | [ ] | [ ] |
| Unzip it on my computer | [ ] | [ ] |
| Open the main README without internet and follow three links | [ ] | [ ] |
| Open one finding aid, one lesson plan, and one picture | [ ] | [ ] |
| Run the fingerprint check; every line should say OK | [ ] | [ ] |

Date of test: [ ]  Problems found: [ ]  What I fixed: [ ]

## 5. What would still be lost if the portfolio moved

- The audiocassette recordings and the 19th-century maps exist only in the Savannah Municipal Archives' PastPerfect system. This portfolio only links to them, and the fingerprint check cannot cover them.
- Live links to PastPerfect, Omeka, and StoryRoots would stop working if those sites changed.
- GitHub's History view of older versions would not travel with a ZIP download.
- [Anything else you notice during the test.]

## 6. Fingerprint check history

| Date | Result | Notes |
|---|---|---|
| 2026-10-12 | All OK | First list created |
| 2026-10-14 | All OK | Lesson plans added |
| 2026-10-22 | Failed | The list still named files that had since been renamed |
| [date] | [ ] | List rebuilt to cover every file |
