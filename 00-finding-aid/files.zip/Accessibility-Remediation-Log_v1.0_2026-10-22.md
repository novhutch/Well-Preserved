# Accessibility Remediation Log

Version 1.0 | 2026-10-22 | Draft

The goal is to meet WCAG 2.1 AA, the standard web accessibility guidelines, so that people using screen readers, magnification, or keyboard-only navigation can use the portfolio. This log keeps adding rows as I check and fix things. "Not yet" means not yet done.

| # | Item | Problem found | Found on | Why it matters to a reader | Fix | Fixed on | How I checked |
|---|---|---|---|---|---|---|---|
| 1 | Four certificate PDFs | No reading structure, so a screen reader may skip the content | 2026-10-22 | A blind reader gets nothing from the page | [ ] | Not yet | [ ] |
| 2 | Finding aids, Accession Record, Deed of Gift, Records Management Policy, Strategic Plan | No document title saved in the file properties [confirm when you open each file] | 2026-10-22 | A screen reader announces the file name instead of a title | [ ] | Not yet | [ ] |
| 3 | Four display photos in the Displays folder; two screenshots in the Audacity folder | No picture descriptions in the README pages | 2026-10-22 | A blind reader cannot tell what the picture shows | [ ] | Not yet | [ ] |
| 4 | Patron Relations presentation | On about half the slides, I could not pull out any text beyond the title, so text may be inside pictures [confirm] | 2026-10-22 | Text inside a picture cannot be read aloud or resized | [ ] | Not yet | [ ] |
| 5 | Lesson plans and Digitization Guide (Word files) | Not yet checked for heading order, picture descriptions, and link wording | Not yet | [ ] | [ ] | Not yet | [ ] |
| 6 | README pages | Not yet checked for heading order and link wording | Not yet | [ ] | [ ] | Not yet | [ ] |
| 7 | Resume PDF | Reading structure and language already set [confirm the date you did this] | [ ] | | Already done | [ ] | [ ] |
| 8 | Color contrast across PDFs and Word files | Not yet checked | Not yet | Low contrast is hard to read | [ ] | Not yet | [ ] |

**What I can explain about why each fix matters:** [After fixing, add one plain sentence per fix about what changes for a real reader.]
